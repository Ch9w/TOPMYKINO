function AProfile() {
	window.location.replace('profile.html')
}
function show_hide_password() {
	var input = document.getElementById('password');
	if (input.getAttribute('type') == 'password') {
		input.setAttribute('type', 'text');
	} else {
		input.setAttribute('type', 'password');
	}
}
function show_hide_password2() {
	var input = document.getElementById('password2');
	if (input.getAttribute('type') == 'password') {
		input.setAttribute('type', 'text');
	} else {
		input.setAttribute('type', 'password');
	}
}
// Фильмы
// id name populars views rating src
let movies = [
	{ id: 1, name: 'BEEKEEPER', populars: 1, views: 1000000, rating: 7, src: 'beekeeper.png' },
	{ id: 2, name: 'Главный герой', populars: 3, views: 2800000, rating: 8, src: 'maingeroi(600-800).jpg' },
	{ id: 3, name: 'Angry Birds 2', populars: 4, views: 4000000, rating: 7.4, src: 'angrybirds2(3_4).png' },
	{ id: 4, name: 'Кухня', populars: 2, views: 10000000, rating: 8.6, src: 'kitchen.jpg' },
	{ id: 5, name: 'Ёлки 5', populars: 6, views: 1500000, rating: 6, src: 'elki5.png' },
	{ id: 6, name: 'GEMINI', populars: 5, views: 700000, rating: 5.2, src: 'gemini.png' }]
function personalSort() {
}
function searchMovie() {
	let sortMovies = document.getElementById('sortMovies').selectedIndex
	switch (sortMovies) {
		case 0:
			movies = movies.sort(function (moviesI, moviesJ) {
				if (moviesI.populars > moviesJ.populars) return 1
				if (moviesI.populars < moviesJ.populars) return -1
				return 0
			})
			break
		case 1:
			movies = movies.sort(function (moviesI, moviesJ) {
				if (moviesI.views > moviesJ.views) return 1
				if (moviesI.views < moviesJ.views) return -1
				return 0
			}).reverse()
			break
		case 2:
			movies = movies.sort(function (moviesI, moviesJ) {
				if (moviesI.rating > moviesJ.rating) return 1
				if (moviesI.rating < moviesJ.rating) return -1
				return 0
			}).reverse()
			break
	}
	const searchMovie = document.getElementById('inputSearchMovie')
	let searchMovies = []
	let numberResult = 1
	let numberArticle = 1
	for (let i = 0; i < movies.length; i++) {
		let str = movies[i].name.toLowerCase()
		if (str.includes(searchMovie.value.toLowerCase())) {
			searchMovies[i] = `<div class="article article${numberArticle} res${numberResult}"> <img src="../assets/img/${movies[i].src}" title="${movies[i].name}" alt="${movies[i].name}">  </div>`
			numberResult++
			numberArticle++
		}
		if (numberArticle == 5) numberArticle = 1
	}
	if (searchMovies.length != 0) {
		document.getElementById('archive').innerHTML = searchMovies.join('')
		document.getElementById('notFound').innerHTML = ''
	}
	else {
		document.getElementById('archive').innerHTML = ""
		document.getElementById('notFound').innerHTML = 'Странно, но здесь ничего нет'
	}
}
function AProfile() {
	window.location.replace('profile.html')
}
function show_hide_password() {
	var input = document.getElementById('password');
	if (input.getAttribute('type') == 'password') {
		input.setAttribute('type', 'text');
	} else {
		input.setAttribute('type', 'password');
	}
}
function show_hide_password2() {
	var input = document.getElementById('password2');
	if (input.getAttribute('type') == 'password') {
		input.setAttribute('type', 'text');
	} else {
		input.setAttribute('type', 'password');
	}
}
function searchMovie() {
	const searchMovie = document.getElementById('inputSearchMovie')
	let movies = ['BEEKEEPER', 'Главный герой', 'Angry Birds 2', 'Кухня', 'Ёлки 5', 'GEMINI']
	let imgMovies = ['beekeeper.png', 'maingeroi(600-800).jpg', 'angrybirds2(3_4).png', 'kitchen.jpg', 'elki5.png', 'gemini.png']
	let searchMovies = []
	let numberResult = 1
	let numberArticle = 1
	for (let i = 0; i < movies.length; i++) {
		let str = movies[i].toLowerCase()
		if (str.includes(searchMovie.value)) {
			searchMovies[i] = '<div class="article article' + numberArticle + ' res' + numberResult + '>'
			+ '<img src=".. &#8260; assets &frasl; img/' + imgMovies[i] + '" title="' + movies[i] + '" alt="' + movies[i] + '" /></div>'
			numberResult++
			numberArticle++
			console.log(i)
		}
		if (numberArticle == 5) numberArticle = 1
	}
	document.getElementById('archive').innerHTML = searchMovies.join('')
}